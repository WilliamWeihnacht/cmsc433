package cmsc433.p1;

public interface Client extends Runnable
{
	String name();
}
