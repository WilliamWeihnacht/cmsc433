package cmsc433.p1;

public interface Bidder extends Client {
	int cash();
	int cashSpent();
	int mostItemsAvailable();
}
